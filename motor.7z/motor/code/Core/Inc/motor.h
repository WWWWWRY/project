#ifndef _MOTOR_H_
#define _MOTOR_H_

#include "main.h"
#include <stdio.h>

#define ENCODER_INITCONST 65535/2
#define PULSE_ONE_ROLL 44.0f
#define UNIT_TIME 5.0f
#define SPEED_RATIO 30.0f
#define MS_TO_S 1000
#define S_TO_MIN 60
#define MOTOR_PWM_MAX 8400
#define MOTOR_PWM_MIN 0

int16_t PWM_controller(TIM_HandleTypeDef *htim,int16_t data);
int16_t Motor_Model_Control(GPIO_PinState STDY,GPIO_PinState AIN1_State,GPIO_PinState AIN2_State);
int16_t Read_Encoder_Pulse(TIM_HandleTypeDef *htim);
float Caculate_Motor_Speed(int16_t pulse);
float PID_Controller(float target_val,float current_val);

#endif
